package com.doc.sharedpref

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnSave.setOnClickListener {

            SharedPref.getInstance(this).saveName(etxName.text.toString())
            Toast.makeText(this,SharedPref.getInstance(this).getName(),Toast.LENGTH_SHORT).show()

        }
    }
}
