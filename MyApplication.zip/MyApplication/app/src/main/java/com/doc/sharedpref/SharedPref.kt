package com.doc.sharedpref

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences

class SharedPref {

    companion object {
        var sharedPreferences: SharedPreferences? = null
        var editor: SharedPreferences.Editor? = null
        val sharePref = SharedPref()


        fun getInstance(context: Context): SharedPref {
            if (sharedPreferences == null) {
                sharedPreferences = context.getSharedPreferences(context.packageName, Activity.MODE_PRIVATE)
                editor = sharedPreferences?.edit();
            }
            return sharePref
        }
    }

    fun saveName(mData: String) {
        if (mData != null) {
            editor!!.putString(Constant.NAME, mData)
            editor!!.apply()
        }
    }

    fun getName(): String {
        var info = sharedPreferences!!.getString(Constant.NAME, "NA")
        return info
    }


}