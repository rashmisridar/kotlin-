package com.doc.sharedpref

object Constant {
    val NAME: String="NAME"
}