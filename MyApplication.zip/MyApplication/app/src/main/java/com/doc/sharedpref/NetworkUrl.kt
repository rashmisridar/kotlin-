package com.doc.sharedpref

object NetworkUrl {
    val BASE_URL :String = ""
}